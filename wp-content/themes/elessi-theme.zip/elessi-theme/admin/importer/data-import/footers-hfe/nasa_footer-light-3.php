<?php
function nasa_hfe_footer_light_3() {
    return array(
        'post' => array(
            'post_title' => 'Footer Light 3',
            'post_name' => 'hfe-footer-light-3'
        ),
        
        'post_meta' => array(
            '_elementor_data' => '[{"id":"16a1a475","elType":"section","settings":{"css_classes":"text-center margin-top-30"},"elements":[{"id":"7c4f4225","elType":"column","settings":{"_column_size":100,"_inline_size":null},"elements":[{"id":"c9460da","elType":"widget","settings":{"wp":{"alt":"","link_text":"#","link_target":"","image":"1703","align":"","hide_in_m":"","el_class":""}},"elements":[],"widgetType":"wp-widget-nasa_image"},{"id":"5bd3266b","elType":"widget","settings":{"wp":{"title":"","text":"<p class=\"text-center margin-bottom-0\">Lorem Ipsum has been the industry standard dummy text ever since the 1500s. Lorem ipsum dolor sit amet, consectetur Nulla fringilla purus Lorem ipsum dosectetur adipisicing elit at leo dignissim congue. Mauris elementum accumsan leo vel tempor.<\/p>","filter":"on","visual":"on"}},"elements":[],"widgetType":"wp-widget-text"},{"id":"7dcfa61d","elType":"widget","settings":{"wp":{"title":"","twitter":"","facebook":"","pinterest":"","email":"","instagram":"","rss":"","linkedin":"","youtube":"","flickr":"","telegram":"","whatsapp":"","amazon":"","tumblr":"","el_class":"margin-top-15"}},"elements":[],"widgetType":"wp-widget-nasa_follow"},{"id":"116c1285","elType":"widget","settings":{"wp":{"title":"","menu":"footer-menu","el_class":"nasa-menu-inline margin-top-10"},"_css_classes":"margin-bottom-0"},"elements":[],"widgetType":"wp-widget-nasa_menu_sc"},{"id":"65c0c240","elType":"widget","settings":{"html":"<p class=\"margin-bottom-0 padding-top-20 padding-bottom-30\">\u00a9 ' . date('Y') . ' - All Right reserved!<\/p>"},"elements":[],"widgetType":"html"}],"isInner":false}],"isInner":false}]',
            '_elementor_css' => 'a:7:{s:4:"time";i:1647679499;s:5:"fonts";a:0:{}s:5:"icons";a:0:{}s:20:"dynamic_elements_ids";a:0:{}s:6:"status";s:5:"empty";i:0;s:0:"";s:3:"css";s:0:"";}',
        ),

        'css' => ''
    );
}
