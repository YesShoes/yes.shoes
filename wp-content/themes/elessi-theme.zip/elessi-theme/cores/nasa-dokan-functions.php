<?php
defined('ABSPATH') or die(); // Exit if accessed directly

/**
 * dokan_enqueue_style
 */
add_action('nasa_before_store_dokan', 'elessi_dokan_enqueue_style');
function elessi_dokan_enqueue_style() {
    global $nasa_opt;
    
    $inMobile = isset($nasa_opt['nasa_in_mobile']) && $nasa_opt['nasa_in_mobile'] ? true : false;
    $themeVersion = isset($nasa_opt['css_theme_version']) && $nasa_opt['css_theme_version'] ? NASA_VERSION : null;
    
    if (!$inMobile) {
        wp_enqueue_style('elessi-style-products-list', ELESSI_THEME_URI . '/assets/css/style-products-list.css', array(), $themeVersion);
    }
}

/**
 * Change view layout
 */
add_action('dokan_store_profile_frame_after', 'elessi_dokan_change_view_store', 15);
if (!function_exists('elessi_dokan_change_view_store')) :
    function elessi_dokan_change_view_store() {
        elessi_nasa_change_view('no');
    }
endif;