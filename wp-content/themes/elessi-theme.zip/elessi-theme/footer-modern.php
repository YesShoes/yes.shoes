<?php
/**
 * The template for displaying the footer.
 *
 * @package nasatheme
 */
?>
</main>
<!-- End Main Content Site -->

</div>
<!-- End Wrapper Site -->

<?php
wp_footer();
echo '</body></html>';
