<?php
/**
 * Product Loop End
 *
 * @author  NasaTheme
 * @package Elessi-theme/WooCommerce
 * @version 2.0.0
 */

if (!defined('ABSPATH')) :
    exit; // Exit if accessed directly
endif;
?>
</ul>
</div>
